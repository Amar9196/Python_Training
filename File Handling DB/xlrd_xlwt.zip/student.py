'''
Created on Jul 18, 2019

@author: srilakshmig
'''
class Student:
    def __init__(self,id,name,testscore):
        self.id = id
        self.name = name
        self.testscore = testscore
    
    def display(self):
        print(self.id,self.name,self.testscore)
    
    def __getstate__(self):
        cloneddict = self.__dict__.copy()  # shallow copy
        del cloneddict["testscore"]
        return cloneddict

    def __setstate__(self, studentdict):
        self.id = studentdict["id"]
        self.name = studentdict["name"]
        self.testscore = "should not be written"