'''
Created on Jul 18, 2019

@author: srilakshmig
'''
import os
 
 
# os.mkdir('sp1')
# os.mkdir('sp2')
#  
# print('directories created')
 
# os.rmdir('sp2')
#  
os.chdir('sp1')
# fo = open('samp.txt', 'w+') 
# fo.write('Welcome to python files')
# # #  
# fo.flush()
# fo.close()
#  
os.rename('samp.txt','samp2.txt')
print(os.getcwd())
# # 
# import collections
# 
# funcList = dir(collections)
# 
# print('Collections functions')
# 
# print(funcList)
