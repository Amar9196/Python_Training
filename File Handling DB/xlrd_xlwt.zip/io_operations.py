'''
Created on Jul 18, 2019

@author: srilakshmig
'''
def writeToFile(fileName,bytearray):
    try:
        with open(fileName, 'w+') as file:
            file.write(bytearray.decode('ascii'));
            file.flush()
            return True
    except IOError as err:
        print(err)
    finally:
        print('finally block')
        file.close()

def readAsWord(fileName):
    try:
        with open(fileName, 'r+') as file:
            for line in file:
                for word in line.split():
                    print(word,end=' & ')
    except IOError as err:
        print(err)
    finally:
        print('finally block')
        file.close()

def readAsLine(fileName):
    try:
        with open(fileName, 'r+') as file:
            for line in file:
                print(line)
    except IOError as err:
        print(err)
    finally:
        print('finally block')
        file.close()

def readFromFile(fileName):
    try:
        with open(fileName, 'a+') as file:
            while True:
                ch = file.read(1)
                if(ch):
                    print(ch,end=' ')
                else:
                    break
    except IOError as err:
        print(err)
    finally:
        print('finally block')
        file.close()

fn = 'simpF.dat'
data = 'yyyuyt555544338876'
ba = bytearray(data,'ascii')
writeToFile(fn, ba)
readFromFile(fn)
data = '''The Indus Valley Civilization, which spread and flourished
in the northwestern part of the Indian subcontinent from c. 3300 to 1300
BCE in present-day Pakistan and northwest India, was the first major
civilization in South Asia.[2] A sophisticated and technologically advanced
urban culture developed in the Mature Harappan period, from 2600 to 1900 BCE.
This civilization collapsed at the start of the second millennium BCE and was
later followed by the Iron Age Vedic Civilization, which extended over
much of the Indo-Gangetic plain and which witness the rise of major polities
known as the Mahajanapadas.
In one of these kingdoms, Magadha, Mahavira and Gautama Buddha propagated
their Shramanic philosophies during the fifth and sixth century BCE.

Most of the subcontinent was conquered by the Maurya Empire during
the 4th and 3rd centuries BCE. From the 3rd century BC onwards Prakrit
and Pali literature in the north and the Sangam literature in southern
India started to flourish.[4][5] The famous Wootz steel originated in
south India in the 3rd century BC and was also exported to foreign countries

Various parts of India were ruled by numerous Middle kingdoms for the
next 1,500 years, among which the Gupta Empire stand out. This period,
witnessing a Hindu religious and intellectual resurgence, is known as
the classical or "Golden Age of India". During this period, aspects of
Indian civilization, administration, culture, and religion (Hinduism
and Buddhism) spread to much of Asia, while kingdoms in southern India
had maritime business links with the Roman Empire from around 77 CE.
During this period Indian cultural influence spread over many parts of
Southeast Asia which led to the establishment of Indianized kingdoms
in Southeast Asia (Greater India)'''
ba = bytearray(data,'ascii')
writeToFile(fn, ba)
print("****as words***")
readAsWord(fn)
print('****as Line****')
readAsLine(fn)