'''
Created on Jul 18, 2019

@author: srilakshmig
'''
import pickle
import day4.student as st
 
# f = open("student.dat","wb")
# s = st.Student(123,"John",90)
# pickle.dump(s,f)
# f.close()

 
f = open("student.dat","rb")
obj = pickle.load(f)
obj.display()
f.close()
