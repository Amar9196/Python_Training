'''
Created on 29-May-2019

@author: srilakshmig
'''


from xlrd import open_workbook
from xlwt import Workbook
from xlutils.copy import copy 
import logging
#reading product & order(transaction)
prod_read = open_workbook(".\product.xls")
order = open_workbook(".\order.xls")
#creating xlwt obj
wt=Workbook()
sh=Workbook()

#s= prod_read.sheet_by_name("Sheet1")
#reading the 1st sheet data from product_file
product_sheet = prod_read.sheet_by_index(0)
#reading the 1st sheet data from order_file
order_sheet=order.sheet_by_index(0)

#adding a new sheet to write 
bill_sheet=wt.add_sheet("Bill")
ship_sheet=sh.add_sheet("Ship")
#creating a copy of product_file
cpy_sheet=copy(prod_read)
#reading the first sheet of copied product_file
s=cpy_sheet.get_sheet(0)

billcount=0
shipcount=0
for i in range(1,order_sheet.nrows):
    found_flag=False
    for j in range(1,product_sheet.nrows):
        if(order_sheet.cell(i,0).value==product_sheet.cell(j,0).value):
            found_flag=True
            if(product_sheet.cell(j,3).value>=order_sheet.cell(i,1).value):
                
                bill_sheet.write(billcount,0,order_sheet.cell(i,2).value)
                bill_sheet.write(billcount,1,product_sheet.cell(j,2).value*order_sheet.cell(i,1).value)
                wt.save("Bill.xls")
                billcount=billcount+1
                s.write(j,3,product_sheet.cell(j,3).value-order_sheet.cell(i,1).value)
                cpy_sheet.save("product.xls")
                
            else:
                
                ship_sheet.write(shipcount,0,order_sheet.cell(i,0).value)
                ship_sheet.write(shipcount,1,'Not Sufficient')
                sh.save("Ship.xls")
                shipcount=shipcount+1
        
    if(found_flag==False):
        
        ship_sheet.write(shipcount,0,order_sheet.cell(i,0).value)
        ship_sheet.write(shipcount,1,'Not Available')
        sh.save("Ship.xls")
        shipcount=shipcount+1

'''        
logger=logging.getLogger(__name__)
logger.setLevel(logging.INFO)
cnhandler=logging.StreamHandler()
logger.addHandler(cnhandler)
logger.log(logging.INFO,"Bill Count:")
logger.info(billcount)
logger.log(logging.INFO,"Ship Count:")
logger.info(shipcount)
'''
#logs --> console, file

logger = logging.getLogger()
logger.setLevel(logging.INFO)
fh = logging.FileHandler("Newlog", "a")
logger.addHandler(fh)
logger.log(logging.INFO,"Bill Count:")
logger.info(billcount)
logger.log(logging.INFO,"Ship Count:")
logger.info(shipcount)
# logger.debug("This is a Debug Message");
# logger.info("This is a Info Message");
# logger.warning("This is a Warning Message");
# logger.critical("This is a Critical Message");
# 
# logger.error("This is a Error Message");
# 
# logging.info("This is a Info Message");
# 
# logging.warning("This is a Warning Message");
# 
# logging.critical("This is a Critical Message");
# 
# logging.error("This is a Error Message");





